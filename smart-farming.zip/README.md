# Wokwi-Smart-Farming

https://wokwi.com/projects/411316435333935105
<br>
https://wokwi-smart-farming.vercel.app/
